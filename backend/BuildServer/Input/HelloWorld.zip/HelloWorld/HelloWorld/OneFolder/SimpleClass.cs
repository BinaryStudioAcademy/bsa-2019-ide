﻿namespace HelloWorld.OneFolder
{
    public class SimpleClass
    {
        private string _simpleData;
        public SimpleClass(int i)
        {
            _simpleData = $"Work!!! + {i}";
        }

        public override string ToString()
        {
            return _simpleData;
        }
    }
}
