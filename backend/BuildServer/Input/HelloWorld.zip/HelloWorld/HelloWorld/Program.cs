﻿using HelloWorld.OneFolder;
using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            for (int i = 0; i < 10; i++)
            {
                SimpleClass simple = new SimpleClass(i);
                Console.WriteLine(simple.ToString());
            }
        }
    }
}
